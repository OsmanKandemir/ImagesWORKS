#! usr/bin/env python
#! -*- coding : utf-8 -*-



from PIL import Image
from PIL import ImageFont
from PIL import ImageDraw 


img = Image.open("example.png")

draw = ImageDraw.Draw(img)


font = ImageFont.truetype("arial.ttf", 50) #50 Yazan Yer Yazi Boyutu #Font'un Path'inide Belirtebilirsin
# draw.text((x, y),"Sample Text",(r,g,b))

draw.text((img.size[0]/2-80, img.size[1]/2),"ORNITORENK",(100,100,100),font=font) #100 yazan yer RENK RGB'leri

#img.size[0]/2 Resim Buyuklugunu Alarak Yaziyi Ortalar

img.save('output.png')

